import os
import sys
import math
import random
import pygame

pygame.init()
try:
    pygame.mixer.init()
    MIXER_OK = True
except pygame.error:
    MIXER_OK = False

os.chdir(os.path.dirname(os.path.abspath(__file__)))

ANCHO, ALTO, FPS = 800, 600, 60
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Un clic, un croar - Salvando al gigante Calipto")
reloj = pygame.time.Clock()

# =====================
# ESTADOS
# =====================
MENU, CINEMATICA, SELECCION, JUGANDO, PAUSA, TRANSICION, GAME_OVER, VICTORIA = range(8)

# =====================
# FUENTES
# =====================
def cargar_fuente(tam):
    try:
        return pygame.font.Font("PressStart2P-Regular.ttf", tam)
    except Exception:
        return pygame.font.SysFont("arial", tam + 6, bold=True)

F_GRANDE = cargar_fuente(28)
F_MEDIANA = cargar_fuente(18)
F_TEXTO = cargar_fuente(12)
F_PEQUENA = cargar_fuente(10)

# =====================
# ASSETS
# =====================
def cargar_img(nombre, tam=None, color=(0, 200, 0), alpha=True):
    try:
        img = pygame.image.load(nombre)
        img = img.convert_alpha() if alpha else img.convert()
    except Exception as e:
        print(f"[aviso] No se pudo cargar {nombre}: {e}")
        img = pygame.Surface(tam or (60, 60))
        img.fill(color)
    if tam:
        img = pygame.transform.scale(img, tam)
    return img

FONDOS = {
    1: cargar_img("bosque.png", (ANCHO, ALTO), alpha=False),
    2: cargar_img("fondo_nivel2.png", (ANCHO, ALTO), alpha=False),
    3: cargar_img("fondo_nivel3.png", (ANCHO, ALTO), alpha=False),
    4: cargar_img("fondo_nivel4.png", (ANCHO, ALTO), alpha=False),
    5: cargar_img("fondo_nivel5.png", (ANCHO, ALTO), alpha=False),
}

SPRITES = {
    1: cargar_img("huevos_sin_fondo.png", (60, 60)),
    2: cargar_img("renacuajo_sin_fondo.png", (70, 70)),
    3: cargar_img("renacuajo_patas_sin_fondo.png", (70, 70)),
    4: cargar_img("rana_adulta_sin_fondo.png", (80, 80)),
    5: cargar_img("rana_gigante_sin_fondo.png", (90, 90)),
}

LLAMA = cargar_img("llama_nivel2.png")

def cargar_sonido(nombre):
    if not MIXER_OK:
        return None
    try:
        return pygame.mixer.Sound(nombre)
    except Exception:
        return None

SONIDO_SALTO = cargar_sonido("Frog-sound.mp3")
SONIDO_PUNTO = cargar_sonido("score.mp3")

def reproducir(sonido):
    if sonido:
        sonido.play()

def musica(activa):
    if not MIXER_OK:
        return
    try:
        if activa:
            pygame.mixer.music.load("Circuit Rush - The Mini Vandals.mp3")
            pygame.mixer.music.set_volume(0.5)
            pygame.mixer.music.play(-1)
        else:
            pygame.mixer.music.stop()
    except Exception:
        pass

# =====================
# DATOS EDUCATIVOS (10 por nivel, se muestran cada 2 puntos)
# =====================
DATOS = {
    1: [
        "Salvando al gigante Calipto",
        "Vivimos en rios, charcos y estanques",
        "Reproduccion: febrero a septiembre",
        "Podemos tener hasta 16.000 hermanos",
        "En 3 semanas nacemos como renacuajos",
        "Las ranas chilenas miden hasta 30 cm",
        "Somos importantes para el ecosistema",
        "Comemos insectos y controlan plagas",
        "Estamos en peligro de extincion",
        "Ayudanos a proteger nuestro habitat",
    ],
    2: [
        "Ahora soy un renacuajo!",
        "Respiro por branquias como los peces",
        "Como algas y plantas acuaticas",
        "Mi cola me ayuda a nadar rapido",
        "Aun no tengo patas desarrolladas",
        "Vivo completamente bajo el agua",
        "Me transformare en rana adulta",
        "La metamorfosis dura varias semanas",
        "Primero me crecen las patas traseras",
        "Luego perdere mi cola gradualmente",
    ],
    3: [
        "Mis patas estan creciendo!",
        "Tarda entre 7 y 9 semanas en crecer patas",
        "En esta fase puedo crecer hasta 15 cm",
        "Mis patas traseras son mas grandes",
        "Empiezo a salir del agua a respirar",
        "Mi cola se esta haciendo mas pequena",
        "Ya puedo saltar fuera del agua",
        "Mis pulmones se estan desarrollando",
        "Pronto sere una ranita completa",
        "La metamorfosis esta casi terminada",
    ],
    4: [
        "Soy una rana joven adulta!",
        "Puedo medir hasta 30 cm de largo",
        "Soy la segunda rana mas grande de Chile",
        "Mi piel es verde oliva con manchas",
        "Vivo en rios y lagunas de agua dulce",
        "Como insectos, aranias y lombrices",
        "Puedo vivir hasta 15 anios",
        "Soy un anfibio muy importante",
        "Estoy en peligro de extincion",
        "Ayuda a proteger mi habitat natural",
    ],
    5: [
        "Soy el gigante Calipto!",
        "Esta rana llega a medir 30 cm",
        "Es la tercera rana mas grande del mundo",
        "Esta rana a vivido 75 millones de anios",
        "Mi color cafe me ayuda a camufarme",
        "Soy un depredador muy efectivo",
        "Como peces pequenos y crustaceos",
        "Mi canto es muy fuerte y profundo",
        "Soy un simbolo de Chile y su naturaleza",
        "Gracias por ayudarme en mi aventura!",
    ],
}

NOMBRES_NIVEL = {
    2: "Renacuajo",
    3: "Renacuajo con patas",
    4: "Rana joven adulta",
    5: "Gigante Calipto",
}

SUBTITULOS_TRANSICION = {
    2: "Ahora soy un renacuajo",
    3: "Me crecen las patas",
    4: "Ahora crecio y es rana adulta mayor",
    5: "Nivel final: el gigante Calipto",
}

# =====================
# BOTONES
# =====================
BTN_JUGAR = pygame.Rect(300, 260, 200, 60)
BTN_PAUSA = pygame.Rect(720, 10, 60, 40)
BTN_REANUDAR = pygame.Rect(300, 250, 200, 50)
BTN_IR_MENU = pygame.Rect(300, 320, 200, 50)
BTN_VOLVER = pygame.Rect(300, 480, 200, 50)

def rect_nivel(i):
    return pygame.Rect(100 + (i - 1) * 130, 250, 100, 80)

# =====================
# VARIABLES DEL JUEGO
# =====================
estado = MENU
nivel_actual = 1
niveles_desbloqueados = 1
siguiente_nivel = 2
puntos = 0
frames_trans = 0
contador = 0          # cuenta regresiva de 3 segundos al reanudar (frames)

jx = 180.0            # posición horizontal fija de la rana
jy = 250.0
jvy = 0.0
GRAVEDAD = 0.45
SALTO = -8.5

tubos = []            # obstáculos (troncos superior e inferior)
ESPACIO = 250         # hueco vertical entre troncos
ANCHO_TRONCO = 80
tiempo_spawn = 0
dato_idx = 0
dato_timer = 0

def velocidad():
    return 2.6 + (nivel_actual - 1) * 0.25

def rect_jugador():
    s = SPRITES[nivel_actual].get_width()
    return pygame.Rect(int(jx) + 10, int(jy) + 10, s - 20, s - 20)

# =====================
# LÓGICA
# =====================
def preparar_nivel(n):
    global nivel_actual, puntos, jy, jvy, tubos, tiempo_spawn
    global dato_idx, dato_timer, estado, contador, frames_trans
    nivel_actual = n
    puntos = 0
    jy = 250.0
    jvy = 0.0
    tubos = []
    tiempo_spawn = 0
    dato_idx = 0
    dato_timer = 0
    contador = 0
    frames_trans = 0
    estado = JUGANDO
    musica(False)

def volver_lobby():
    global estado, nivel_actual, puntos, tubos, contador
    estado = MENU
    nivel_actual = 1
    puntos = 0
    tubos = []
    contador = 0
    musica(True)

def morir():
    global estado
    estado = GAME_OVER
    musica(False)

def completar_nivel():
    global estado, siguiente_nivel, niveles_desbloqueados, frames_trans
    if nivel_actual < 5:
        siguiente_nivel = nivel_actual + 1
        niveles_desbloqueados = max(niveles_desbloqueados, siguiente_nivel)
        estado = TRANSICION
        frames_trans = 0
    else:
        niveles_desbloqueados = 5
        estado = VICTORIA
        musica(False)

def actualizar_juego():
    global jy, jvy, puntos, tiempo_spawn, dato_idx, dato_timer, tubos
    jvy += GRAVEDAD
    jy += jvy
    if jy < 0:
        jy = 0
        jvy = 0
    if jy + SPRITES[nivel_actual].get_height() > ALTO:
        morir()
        return

    tiempo_spawn += 1
    if tiempo_spawn >= 130:
        tiempo_spawn = 0
        tubos.append({"x": ANCHO, "hueco": random.randint(170, 430), "pasado": False})

    for t in tubos:
        t["x"] -= velocidad()

    jug = rect_jugador()
    for t in tubos:
        arriba = pygame.Rect(int(t["x"]), 0, ANCHO_TRONCO, int(t["hueco"] - ESPACIO / 2))
        abajo = pygame.Rect(int(t["x"]), int(t["hueco"] + ESPACIO / 2), ANCHO_TRONCO, ALTO)
        if jug.colliderect(arriba) or jug.colliderect(abajo):
            morir()
            return
        if not t["pasado"] and t["x"] + ANCHO_TRONCO < jx:
            t["pasado"] = True
            puntos += 1
            reproducir(SONIDO_PUNTO)
            if puntos % 2 == 0:
                dato_idx = min(puntos // 2 - 1, len(DATOS[nivel_actual]) - 1)
                dato_timer = 180

    tubos = [t for t in tubos if t["x"] > -ANCHO_TRONCO]
    if dato_timer > 0:
        dato_timer -= 1
    if puntos >= 20:
        completar_nivel()

def actualizar():
    global contador, frames_trans
    if estado == JUGANDO:
        if contador > 0:
            contador -= 1
        else:
            actualizar_juego()
    elif estado == TRANSICION:
        frames_trans += 1

# =====================
# EVENTOS
# =====================
def manejar(e):
    global estado, jvy, contador
    if e.type == pygame.QUIT:
        pygame.quit()
        sys.exit()

    click = e.type == pygame.MOUSEBUTTONDOWN and e.button == 1
    pos = e.pos if click else None
    space = e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE
    tecla_pausa = e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_p)

    if estado == MENU:
        if space or (click and BTN_JUGAR.collidepoint(pos)):
            estado = CINEMATICA

    elif estado == CINEMATICA:
        if space or click:
            estado = SELECCION

    elif estado == SELECCION:
        if click:
            for i in range(1, 6):
                if rect_nivel(i).collidepoint(pos) and i <= niveles_desbloqueados:
                    preparar_nivel(i)
                    return
            if BTN_VOLVER.collidepoint(pos):
                estado = MENU

    elif estado == JUGANDO:
        if tecla_pausa or (click and BTN_PAUSA.collidepoint(pos)):
            estado = PAUSA
        elif (space or click) and contador == 0:
            jvy = SALTO
            reproducir(SONIDO_SALTO)

    elif estado == PAUSA:
        if tecla_pausa or (click and BTN_REANUDAR.collidepoint(pos)):
            contador = 180
            estado = JUGANDO
        elif click and BTN_IR_MENU.collidepoint(pos):
            volver_lobby()

    elif estado == TRANSICION:
        if (space or click) and frames_trans > 60:
            preparar_nivel(siguiente_nivel)

    elif estado in (GAME_OVER, VICTORIA):
        if space or click:
            volver_lobby()

# =====================
# DIBUJO
# =====================
def texto(fuente, s, cx, cy, color=(255, 255, 255)):
    surf = fuente.render(s, True, color)
    pantalla.blit(surf, surf.get_rect(center=(cx, cy)))

def boton(rect, s, color=(0, 200, 0)):
    pygame.draw.rect(pantalla, color, rect, border_radius=8)
    pygame.draw.rect(pantalla, (255, 255, 255), rect, 2, border_radius=8)
    texto(F_TEXTO, s, rect.centerx, rect.centery, (0, 0, 0))

def dibujar_menu():
    pantalla.blit(FONDOS[1], (0, 0))
    texto(F_GRANDE, "UN CLIC, UN CROAR", ANCHO // 2, 150, (0, 255, 0))
    texto(F_TEXTO, "Salvando al gigante Calipto", ANCHO // 2, 200, (255, 255, 0))
    boton(BTN_JUGAR, "JUGAR")

def dibujar_cinematica():
    pantalla.blit(FONDOS[1], (0, 0))
    overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 170))
    pantalla.blit(overlay, (0, 0))
    texto(F_MEDIANA, "BIENVENIDO!", ANCHO // 2, 150, (255, 255, 0))
    texto(F_TEXTO, "Esta es la historia del", ANCHO // 2, 250)
    texto(F_TEXTO, "Gigante Calipto", ANCHO // 2, 290)
    texto(F_PEQUENA, "PRESIONA SPACE O TAP PARA CONTINUAR", ANCHO // 2, 450, (0, 255, 0))

def dibujar_seleccion():
    pantalla.blit(FONDOS[1], (0, 0))
    texto(F_MEDIANA, "SELECCIONA NIVEL", ANCHO // 2, 80, (0, 255, 0))
    for i in range(1, 6):
        r = rect_nivel(i)
        if i <= niveles_desbloqueados:
            boton(r, f"NIVEL {i}")
        else:
            pygame.draw.rect(pantalla, (80, 80, 80), r, border_radius=8)
            pygame.draw.rect(pantalla, (150, 150, 150), r, 3, border_radius=8)
            texto(F_TEXTO, "LOCK", r.centerx, r.centery, (200, 200, 200))
    boton(BTN_VOLVER, "VOLVER", (120, 120, 120))

def dibujar_transicion():
    pantalla.fill((0, 0, 0))
    n = siguiente_nivel
    escala = 350 + math.sin(frames_trans * 0.08) * 40
    llama = pygame.transform.scale(LLAMA, (int(escala), int(escala)))
    pantalla.blit(llama, llama.get_rect(center=(ANCHO // 2, ALTO // 2 + 30)))

    rana = pygame.transform.scale(SPRITES[n], (140, 140))
    rana = pygame.transform.rotate(rana, frames_trans * 2)
    pantalla.blit(rana, rana.get_rect(center=(ANCHO // 2, ALTO // 2 + 30)))

    texto(F_GRANDE, f"NIVEL {n}", ANCHO // 2, 60, (255, 255, 0))
    texto(F_MEDIANA, "FELICIDADES!", ANCHO // 2, 120, (0, 255, 0))
    texto(F_TEXTO, NOMBRES_NIVEL[n], ANCHO // 2, 160, (255, 255, 255))
    texto(F_PEQUENA, SUBTITULOS_TRANSICION[n], ANCHO // 2, 190, (100, 255, 100))
    if frames_trans > 60:
        texto(F_TEXTO, "PRESIONA SPACE", ANCHO // 2, 520, (255, 255, 255))
        texto(F_TEXTO, "PARA COMENZAR", ANCHO // 2, 550, (255, 255, 255))

def dibujar_juego():
    pantalla.blit(FONDOS[nivel_actual], (0, 0))

    for t in tubos:
        pygame.draw.rect(pantalla, (139, 69, 19),
                         (int(t["x"]), 0, ANCHO_TRONCO, int(t["hueco"] - ESPACIO / 2)))
        pygame.draw.rect(pantalla, (139, 69, 19),
                         (int(t["x"]), int(t["hueco"] + ESPACIO / 2), ANCHO_TRONCO, ALTO))

    pantalla.blit(SPRITES[nivel_actual], (int(jx), int(jy)))

    texto(F_PEQUENA, f"NIVEL {nivel_actual}   PUNTOS {puntos}/20", 150, 25, (255, 255, 0))

    if dato_timer > 0:
        caja = pygame.Surface((700, 100), pygame.SRCALPHA)
        caja.fill((0, 0, 0, 160))
        pantalla.blit(caja, (50, 470))
        texto(F_PEQUENA, DATOS[nivel_actual][dato_idx], ANCHO // 2, 520, (255, 255, 0))

    # Botón de pausa
    pygame.draw.rect(pantalla, (40, 40, 40), BTN_PAUSA, border_radius=6)
    pygame.draw.rect(pantalla, (255, 255, 255), BTN_PAUSA, 2, border_radius=6)
    pygame.draw.rect(pantalla, (255, 255, 255), (736, 20, 8, 20))
    pygame.draw.rect(pantalla, (255, 255, 255), (750, 20, 8, 20))

    if contador > 0:
        texto(F_GRANDE, str(math.ceil(contador / 60)), ANCHO // 2, 300, (255, 255, 0))

def dibujar_pausa():
    dibujar_juego()
    overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    pantalla.blit(overlay, (0, 0))
    texto(F_GRANDE, "PAUSA", ANCHO // 2, 170, (255, 0, 0))
    boton(BTN_REANUDAR, "REANUDAR")
    boton(BTN_IR_MENU, "IR AL MENU", (120, 120, 120))
    texto(F_PEQUENA, "ESC o P para continuar", ANCHO // 2, 420)

def dibujar_game_over():
    overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    pantalla.blit(overlay, (0, 0))
    texto(F_GRANDE, "GAME OVER", ANCHO // 2, 180, (255, 0, 0))
    texto(F_MEDIANA, f"Puntos: {puntos}", ANCHO // 2, 260, (255, 255, 0))
    texto(F_PEQUENA, "PRESIONA SPACE PARA VOLVER AL LOBBY", ANCHO // 2, 400, (0, 255, 0))

def dibujar_victoria():
    pantalla.fill((0, 0, 50))
    texto(F_MEDIANA, "FELICIDADES!", ANCHO // 2, 60, (255, 215, 0))
    texto(F_TEXTO, "Completaste el juego", ANCHO // 2, 110)
    mensaje = [
        "Gracias por jugar este juego",
        "Le he metido mucho esfuerzo",
        "para mi feria",
        "",
        "Muchas gracias por el apoyo",
        "",
        "Gracias por jugar!",
    ]
    y = 180
    for linea in mensaje:
        if linea:
            texto(F_TEXTO, linea, ANCHO // 2, y)
        y += 35
    pantalla.blit(pygame.transform.scale(SPRITES[5], (120, 120)), (50, 430))
    pantalla.blit(pygame.transform.scale(SPRITES[5], (120, 120)), (ANCHO - 170, 430))
    texto(F_PEQUENA, "PRESIONA SPACE PARA IR AL LOBBY", ANCHO // 2, 540, (0, 255, 0))

def dibujar():
    if estado == MENU:
        dibujar_menu()
    elif estado == CINEMATICA:
        dibujar_cinematica()
    elif estado == SELECCION:
        dibujar_seleccion()
    elif estado == JUGANDO:
        dibujar_juego()
    elif estado == PAUSA:
        dibujar_pausa()
    elif estado == TRANSICION:
        dibujar_transicion()
    elif estado == GAME_OVER:
        dibujar_juego()
        dibujar_game_over()
    elif estado == VICTORIA:
        dibujar_victoria()

# =====================
# BUCLE PRINCIPAL
# =====================
def main():
    musica(True)
    while True:
        for e in pygame.event.get():
            manejar(e)
        actualizar()
        dibujar()
        pygame.display.flip()
        reloj.tick(FPS)

if __name__ == "__main__":
    main()
