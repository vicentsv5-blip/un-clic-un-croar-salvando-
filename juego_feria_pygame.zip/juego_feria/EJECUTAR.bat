@echo off
cd /d "%~dp0"
python juego.py
pause
